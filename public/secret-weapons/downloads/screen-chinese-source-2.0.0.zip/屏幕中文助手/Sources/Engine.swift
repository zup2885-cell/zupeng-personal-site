import AppKit
import SwiftUI
import Translation

enum EnglishFilter {
    static func accepts(_ text: String) -> Bool {
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 8000 else { return false }
        if text.range(of: "^(https?://|www\\.|[\\w.+-]+@[\\w.-]+\\.[a-z]{2,})", options: [.regularExpression, .caseInsensitive]) != nil { return false }
        if ["GitHub", "GitLab", "Google", "Apple", "OpenAI", "ChatGPT", "macOS", "iOS", "Chrome", "Safari"].contains(text) { return false }
        if !text.contains(" "), text.range(of: "[0-9_/\\\\]|\\.[a-zA-Z0-9]{1,8}$", options: .regularExpression) != nil { return false }
        let latin = text.unicodeScalars.filter { (65...90).contains($0.value) || (97...122).contains($0.value) }.count
        let han = text.unicodeScalars.filter { (0x3400...0x9fff).contains($0.value) }.count
        return latin >= 2 && latin > han * 3
    }
}

struct WebSegment: Codable, Hashable { let text: String; let plain: Bool; let protected: Bool }
struct WebRun: Codable { let node: Int; let text: String }
struct WebResult: Codable { let contextual: Bool; let runs: [WebRun] }

@MainActor final class TranslationEngine {
    private var session: TranslationSession?
    private var cache: [String: String] = [:]
    private var richCache: [[WebSegment]: WebResult] = [:]
    private let fast: Bool
    init(fast: Bool = false) { self.fast = fast }
    private func currentSession() -> TranslationSession {
        if let session { return session }
        let result: TranslationSession
        if #available(macOS 26.4, *) {
            result = TranslationSession(installedSource: .init(identifier: "en"), target: .init(identifier: "zh-Hans"), preferredStrategy: fast ? .lowLatency : .highFidelity)
        } else { result = TranslationSession(installedSource: .init(identifier: "en"), target: .init(identifier: "zh-Hans")) }
        session = result
        return result
    }
    func translate(_ texts: [String]) async throws -> [String] {
        let missing = Array(Set(texts.filter { cache[$0] == nil && EnglishFilter.accepts($0) })).sorted()
        for start in stride(from: 0, to: missing.count, by: 16) {
            try Task.checkCancellation()
            let batch = Array(missing[start..<min(start + 16, missing.count)])
            do {
                let responses = try await currentSession().translations(from: batch.enumerated().map { .init(sourceText: $0.element, clientIdentifier: String($0.offset)) })
                for response in responses {
                    guard let id = response.clientIdentifier, let index = Int(id), batch.indices.contains(index), !response.targetText.isEmpty else { continue }
                    cache[batch[index]] = response.targetText
                }
                guard batch.allSatisfy({ cache[$0] != nil }) else { throw CocoaError(.coderReadCorrupt) }
            } catch {
                session?.cancel(); session = nil
                throw error
            }
        }
        let result = texts.map { cache[$0] ?? $0 }
        if cache.count > 2500 { cache = Dictionary(zip(texts, result), uniquingKeysWith: { first, _ in first }) }
        return result
    }
    func translateUnits(_ units: [[WebSegment]]) async throws -> [WebResult] {
        // Most webpage nodes are plain text: batch these together instead of
        // starting a model request for every heading and button separately.
        let plainTexts = units.filter { $0.count == 1 && !$0[0].protected }.map { $0[0].text }
        _ = try await translate(plainTexts)
        var results: [WebResult] = []
        for unit in units {
            try Task.checkCancellation()
            if let cached = richCache[unit] { results.append(cached); continue }
            let result: WebResult
            if unit.count == 1 {
                let text = unit[0].protected ? unit[0].text : try await translate([unit[0].text])[0]
                result = WebResult(contextual: false, runs: [.init(node: 0, text: text)])
            } else if #available(macOS 26.4, *), let contextual = try? await contextualTranslation(unit) {
                result = contextual
            } else {
                let texts = try await translate(unit.map { $0.protected ? "" : $0.text })
                result = WebResult(contextual: false, runs: unit.indices.map { .init(node: $0, text: unit[$0].protected ? unit[$0].text : texts[$0]) })
            }
            richCache[unit] = result; results.append(result)
        }
        if richCache.count > 1000 { richCache.removeAll(keepingCapacity: true) }
        return results
    }
    @available(macOS 26.4, *) private func contextualTranslation(_ segments: [WebSegment]) async throws -> WebResult? {
        var source = AttributedString()
        for (index, segment) in segments.enumerated() {
            var part = AttributedString(segment.text)
            // Synthetic link attributes track ownership through translated word
            // order. No URL is opened or transmitted; these tags stay in memory.
            part.link = URL(string: "https://segment.invalid/\(index)")
            if segment.protected { part.translation.skipsTranslation = true }
            source.append(part)
        }
        let response = try await currentSession().translate(source)
        guard let target = response.attributedTargetText else { return nil }
        var runs: [WebRun] = []
        for run in target.runs {
            let text = String(target[run.range].characters)
            guard let url = run.link, url.host == "segment.invalid", let index = Int(url.lastPathComponent), segments.indices.contains(index) else { return nil }
            if let previous = runs.last, previous.node == index {
                runs[runs.count - 1] = WebRun(node: index, text: previous.text + text)
            } else { runs.append(.init(node: index, text: text)) }
        }
        guard !runs.isEmpty else { return nil }
        for (index, segment) in segments.enumerated() {
            let matching = runs.filter { $0.node == index }
            if !segment.plain && matching.count != 1 { return nil }
            if segment.protected && matching.map(\.text).joined().trimmingCharacters(in: .whitespacesAndNewlines) != segment.text.trimmingCharacters(in: .whitespacesAndNewlines) { return nil }
        }
        return WebResult(contextual: true, runs: runs)
    }
}

@MainActor final class LanguageModel: ObservableObject {
    @Published var ready = false
    @Published var checking = true
    @Published var preparing = false
    @Published var message = "正在检查本机翻译…"
    @Published var configuration: TranslationSession.Configuration?
    var onReady: (() -> Void)?
    func check() async {
        checking = true; defer { checking = false }
        let state = await LanguageAvailability().status(from: .init(identifier: "en"), to: .init(identifier: "zh-Hans"))
        ready = state == .installed
        if !ready && UserDefaults.standard.bool(forKey: "offlineLanguagePairVerified") {
            ready = (try? await TranslationEngine(fast: true).translate(["Hello"])) != nil
        }
        message = ready ? "本机英译中已就绪，无需账号或密钥。" : "首次需由系统下载英语和简体中文语言包，之后翻译可离线使用。"
        if ready { UserDefaults.standard.set(true, forKey: "offlineLanguagePairVerified"); onReady?() }
    }
    func prepare() {
        guard !preparing else { return }; preparing = true
        if configuration == nil { configuration = .init(source: .init(identifier: "en"), target: .init(identifier: "zh-Hans")) }
        else { configuration?.invalidate() }
    }
    func prepare(using session: TranslationSession) async {
        defer { preparing = false }
        do { try await session.prepareTranslation(); await check() }
        catch { message = "语言包尚未就绪：\(error.localizedDescription)" }
    }
}

struct LanguageView: View {
    @ObservedObject var model: LanguageModel
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Label("屏幕中文助手", systemImage: "character.bubble.fill").font(.title2.bold())
            Text(model.message).fixedSize(horizontal: false, vertical: true)
            Text("翻译在本机完成，不需要填写 API。屏幕模式需要 macOS 的屏幕录制权限；网页窗口无需该权限。").font(.callout).foregroundStyle(.secondary)
            HStack {
                if model.checking || model.preparing { ProgressView().controlSize(.small) }
                Spacer()
                Button(model.ready ? "已准备好" : "下载语言包") { model.prepare() }.disabled(model.ready || model.checking || model.preparing).buttonStyle(.borderedProminent)
            }
        }.padding(26).frame(width: 430)
        .translationTask(model.configuration) { session in await model.prepare(using: session) }
    }
}
