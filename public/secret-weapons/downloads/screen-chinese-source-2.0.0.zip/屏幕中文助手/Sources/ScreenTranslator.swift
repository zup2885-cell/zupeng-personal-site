import AppKit
import ScreenCaptureKit
import Vision
import CoreImage
import CoreMedia
import QuartzCore

struct DetectedText { let source: String; let rect: CGRect }
struct GrayFrame {
    static let width = 640, height = 400
    let pixels: [UInt8]
    init?(_ image: CGImage) {
        var bytes = [UInt8](repeating: 0, count: Self.width * Self.height)
        let okay = bytes.withUnsafeMutableBytes { data -> Bool in
            guard let context = CGContext(data: data.baseAddress, width: Self.width, height: Self.height, bitsPerComponent: 8, bytesPerRow: Self.width, space: CGColorSpaceCreateDeviceGray(), bitmapInfo: 0) else { return false }
            context.interpolationQuality = .low
            context.draw(image, in: CGRect(x: 0, y: 0, width: Self.width, height: Self.height)); return true
        }
        if !okay { return nil }; pixels = bytes
    }
    func differs(from other: GrayFrame, regions: [CGRect]) -> Bool {
        let regions = regions.isEmpty ? [CGRect(x: 0, y: 0, width: 1, height: 1)] : regions
        for r in regions {
            let x0 = max(0, Int(r.minX * CGFloat(Self.width)) - 2), x1 = min(Self.width, Int(r.maxX * CGFloat(Self.width)) + 2)
            let y0 = max(0, Int((1 - r.maxY) * CGFloat(Self.height)) - 2), y1 = min(Self.height, Int((1 - r.minY) * CGFloat(Self.height)) + 2)
            guard x1 > x0, y1 > y0 else { continue }
            var changed = 0, count = 0
            let strideSize = regions.count == 1 && r.width == 1 ? 3 : 1
            for y in stride(from: y0, to: y1, by: strideSize) {
                for x in stride(from: x0, to: x1, by: strideSize) {
                    let i = y * Self.width + x
                    if abs(Int(pixels[i]) - Int(other.pixels[i])) >= 14 { changed += 1 }
                    count += 1
                }
            }
            if changed >= 3 && Double(changed) / Double(max(1, count)) > 0.016 { return true }
        }
        return false
    }
}

// A single-slot mailbox prevents a busy main thread receiving old frames later.
final class ScreenFrames: NSObject, SCStreamOutput, SCStreamDelegate {
    private let context = CIContext(options: [.cacheIntermediates: false])
    private let lock = NSLock()
    private var latest: (CGImage, GrayFrame, CFTimeInterval)?
    private var scheduled = false
    var receive: ((CGImage, GrayFrame, CFTimeInterval) -> Void)?
    var failed: ((Error) -> Void)?
    func stream(_ stream: SCStream, didStopWithError error: Error) { DispatchQueue.main.async { [weak self] in self?.failed?(error) } }
    func stream(_ stream: SCStream, didOutputSampleBuffer buffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .screen, buffer.isValid, let pixel = CMSampleBufferGetImageBuffer(buffer) else { return }
        let date = CACurrentMediaTime()
        let image = CIImage(cvPixelBuffer: pixel)
        guard let cg = context.createCGImage(image, from: image.extent), let sample = GrayFrame(cg) else { return }
        lock.lock(); latest = (cg, sample, date)
        let shouldSchedule = !scheduled; scheduled = true; lock.unlock()
        if shouldSchedule {
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.lock.lock(); let value = self.latest; self.latest = nil; self.scheduled = false; self.lock.unlock()
                if let value { self.receive?(value.0, value.1, value.2) }
            }
        }
    }
}

final class ChineseOverlayWindow: NSWindow {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

@MainActor final class ScreenTranslator {
    private var stream: SCStream?
    private var receiver: ScreenFrames?
    private let queue = DispatchQueue(label: "ScreenChinese.capture", qos: .userInteractive)
    private let engine = TranslationEngine(fast: true)
    private var timer: Timer?
    private var monitor: Any?
    private var localMonitor: Any?
    private var workspaceObserver: NSObjectProtocol?
    private var image: CGImage?
    private var sample: GrayFrame?
    private var previous: GrayFrame?
    private var committed: GrayFrame?
    private var regions: [CGRect] = []
    private var stableAfter: CFTimeInterval = 0
    private var generation = 0
    private var busy = false
    private var starting = false
    private var overlay: ChineseOverlayWindow?
    private var labels: [String: NSTextField] = [:]
    private var screen: NSScreen?
    private(set) var active = false
    private(set) var frameCount = 0
    private(set) var discarded = 0
    private(set) var translatedCount = 0
    var statusChanged: ((String) -> Void)?
    var suppressForOwnWindow: (() -> Bool)?

    func start(screen: NSScreen?) {
        guard !active, !starting else { return }
        guard CGPreflightScreenCaptureAccess() else { statusChanged?("屏幕模式需要一次屏幕录制授权。网页翻译窗口可直接使用。"); return }
        guard let screen else { return }
        self.screen = screen; starting = true; active = true
        Task {
            do {
                let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
                guard active else { starting = false; return }
                let number = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber
                guard let display = content.displays.first(where: { $0.displayID == number?.uint32Value }) else { throw CocoaError(.featureUnsupported) }
                let own = content.applications.filter { $0.processID == ProcessInfo.processInfo.processIdentifier }
                let filter = SCContentFilter(display: display, excludingApplications: own, exceptingWindows: [])
                let config = SCStreamConfiguration()
                let scale = min(1.0, 1920.0 / Double(display.width))
                config.width = Int(Double(display.width) * scale); config.height = Int(Double(display.height) * scale)
                config.minimumFrameInterval = CMTime(value: 1, timescale: 15)
                config.queueDepth = 3; config.showsCursor = false; config.capturesAudio = false
                let receiver = ScreenFrames()
                receiver.receive = { [weak self] image, sample, date in self?.received(image, sample: sample, date: date) }
                receiver.failed = { [weak self] error in self?.stop(); self?.statusChanged?("屏幕读取中断：\(error.localizedDescription)") }
                self.receiver = receiver
                let stream = SCStream(filter: filter, configuration: config, delegate: receiver)
                self.stream = stream
                try stream.addStreamOutput(receiver, type: .screen, sampleHandlerQueue: queue)
                try await stream.startCapture()
                guard active else { try? await stream.stopCapture(); starting = false; return }
                starting = false
                monitor = NSEvent.addGlobalMonitorForEvents(matching: [.scrollWheel, .leftMouseDown, .rightMouseDown, .leftMouseDragged]) { [weak self] event in self?.invalidate(delay: event.type == .scrollWheel ? 0.38 : 0.2) }
                localMonitor = NSEvent.addLocalMonitorForEvents(matching: [.scrollWheel, .leftMouseDragged]) { [weak self] event in self?.invalidate(delay: 0.38); return event }
                workspaceObserver = NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.didActivateApplicationNotification, object: nil, queue: .main) { [weak self] _ in MainActor.assumeIsolated { self?.invalidate(delay: 0.3) } }
                timer = Timer.scheduledTimer(withTimeInterval: 0.12, repeats: true) { [weak self] _ in MainActor.assumeIsolated { self?.refresh() } }
                statusChanged?("屏幕自动翻译中 · 滚动时隐藏旧译文")
            } catch { starting = false; stop(); statusChanged?("无法读取屏幕：\(error.localizedDescription)") }
        }
    }
    private func received(_ image: CGImage, sample: GrayFrame, date: CFTimeInterval) {
        guard active else { return }; frameCount += 1
        guard CACurrentMediaTime() - date <= 0.2 else { invalidate(delay: 0.3); return }
        self.image = image; self.sample = sample
        if suppressForOwnWindow?() == true { invalidate(delay: 0.25); previous = sample; return }
        if let previous, sample.differs(from: previous, regions: regions) { invalidate(delay: 0.3) }
        self.previous = sample
    }
    func invalidate(delay: Double = 0.3) {
        generation += 1; stableAfter = CACurrentMediaTime() + delay
        committed = nil
        overlay?.orderOut(nil)
        // Keep watching the last source regions while Chinese is hidden.
        // Otherwise inertia can make old translations reappear mid-scroll.
    }
    private func refresh() {
        guard active, !busy, suppressForOwnWindow?() != true, CACurrentMediaTime() >= stableAfter, let image, let sample else { return }
        if let committed, !sample.differs(from: committed, regions: []) { return }
        busy = true
        let version = generation
        Task {
            defer { busy = false }
            do {
                let lines = try await Task.detached(priority: .userInitiated) { try Self.recognize(image) }.value
                guard active, version == generation, let current = self.sample, !current.differs(from: sample, regions: lines.map(\.rect)) else { discarded += 1; return }
                regions = lines.map(\.rect)
                let targets = try await engine.translate(lines.map(\.source))
                guard active, version == generation, CACurrentMediaTime() >= stableAfter, let final = self.sample, !final.differs(from: sample, regions: regions), suppressForOwnWindow?() != true else { discarded += 1; return }
                show(lines, targets: targets, source: image)
                committed = sample; translatedCount = lines.count
            } catch {
                overlay?.orderOut(nil); stableAfter = CACurrentMediaTime() + 2
                statusChanged?("翻译暂时中断，将自动重试。\(error.localizedDescription)")
            }
        }
    }
    nonisolated static func recognize(_ image: CGImage) throws -> [DetectedText] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate; request.recognitionLanguages = ["en-US"]
        request.usesLanguageCorrection = true; request.minimumTextHeight = 0.006
        try VNImageRequestHandler(cgImage: image).perform([request])
        return (request.results ?? []).compactMap { observation in
            guard let text = observation.topCandidates(1).first, text.confidence >= 0.35, EnglishFilter.accepts(text.string) else { return nil }
            return DetectedText(source: text.string, rect: observation.boundingBox)
        }.prefix(100).map { $0 }
    }
    private func show(_ lines: [DetectedText], targets: [String], source: CGImage) {
        guard let screen else { return }
        if overlay == nil {
            let window = ChineseOverlayWindow(contentRect: screen.frame, styleMask: .borderless, backing: .buffered, defer: false)
            window.isOpaque = false; window.backgroundColor = .clear; window.hasShadow = false
            window.ignoresMouseEvents = true; window.level = .floating
            window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
            overlay = window
        }
        guard let view = overlay?.contentView else { return }
        var next: [String: NSTextField] = [:]
        for (index, line) in lines.enumerated() where targets.indices.contains(index) && targets[index] != line.source {
            let r = CGRect(x: line.rect.minX * screen.frame.width, y: line.rect.minY * screen.frame.height, width: line.rect.width * screen.frame.width, height: line.rect.height * screen.frame.height).insetBy(dx: -1, dy: -1)
            let key = "\(index)|\(line.source)|\(targets[index])"
            let field = labels[key] ?? NSTextField(labelWithString: targets[index])
            field.frame = r; field.drawsBackground = true; field.maximumNumberOfLines = 1
            let background = Self.background(source, rect: line.rect)
            field.backgroundColor = background
            let luminance = 0.2126 * background.redComponent + 0.7152 * background.greenComponent + 0.0722 * background.blueComponent
            field.textColor = luminance > 0.5 ? NSColor(calibratedWhite: 0.12, alpha: 1) : NSColor(calibratedWhite: 0.95, alpha: 1)
            let fontSize = max(1, r.height * 0.78)
            let width = (targets[index] as NSString).size(withAttributes: [.font: NSFont.systemFont(ofSize: fontSize)]).width
            field.font = .systemFont(ofSize: fontSize * min(1, max(1, r.width - 3) / max(1, width)))
            field.lineBreakMode = .byClipping
            if field.superview == nil { view.addSubview(field) }
            next[key] = field
        }
        for (key, field) in labels where next[key] == nil { field.removeFromSuperview() }
        labels = next
        if !labels.isEmpty { overlay?.orderFrontRegardless() } else { overlay?.orderOut(nil) }
    }
    nonisolated private static func background(_ image: CGImage, rect: CGRect) -> NSColor {
        // Sample a narrow strip just above the text, keeping screenshots in memory.
        let r = CGRect(x: rect.minX * CGFloat(image.width), y: (1 - rect.maxY) * CGFloat(image.height) - 3, width: max(1, rect.width * CGFloat(image.width)), height: 2).intersection(CGRect(x: 0, y: 0, width: image.width, height: image.height))
        guard !r.isEmpty, let crop = image.cropping(to: r) else { return .white }
        var pixel = [UInt8](repeating: 0, count: 4)
        pixel.withUnsafeMutableBytes { data in
            guard let context = CGContext(data: data.baseAddress, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
            context.draw(crop, in: CGRect(x: 0, y: 0, width: 1, height: 1))
        }
        return NSColor(calibratedRed: CGFloat(pixel[0])/255, green: CGFloat(pixel[1])/255, blue: CGFloat(pixel[2])/255, alpha: 1)
    }
    func stop() {
        active = false; generation += 1; timer?.invalidate(); timer = nil
        if let monitor { NSEvent.removeMonitor(monitor) }; monitor = nil
        if let localMonitor { NSEvent.removeMonitor(localMonitor) }; localMonitor = nil
        if let workspaceObserver { NSWorkspace.shared.notificationCenter.removeObserver(workspaceObserver) }; workspaceObserver = nil
        let old = stream; stream = nil
        Task { try? await old?.stopCapture() }
        receiver = nil; image = nil; sample = nil; previous = nil; committed = nil; regions = []
        overlay?.orderOut(nil); overlay = nil; labels.removeAll()
        statusChanged?("屏幕翻译已暂停")
    }
    var diagnostic: [String: Any] {
        ["active": active, "frames": frameCount, "discarded": discarded, "translatedCount": translatedCount, "overlayVisible": overlay?.isVisible ?? false, "mousePassthrough": overlay?.ignoresMouseEvents ?? true, "scrollPolicy": "hide-until-stable", "captureAllowed": CGPreflightScreenCaptureAccess()]
    }
}
