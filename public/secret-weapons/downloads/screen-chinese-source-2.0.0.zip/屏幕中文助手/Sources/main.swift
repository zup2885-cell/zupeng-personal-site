import AppKit
import Darwin

let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/ScreenChineseAssistant")
try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
let lock = open(directory.appendingPathComponent("instance.lock").path, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR)
if !CommandLine.arguments.contains("--verify") {
    guard lock >= 0 else { exit(1) }
    if flock(lock, LOCK_EX | LOCK_NB) != 0 {
        NSWorkspace.shared.openApplication(at: Bundle.main.bundleURL, configuration: NSWorkspace.OpenConfiguration()) { _, _ in }
        exit(0)
    }
}
MainActor.assumeIsolated {
    let app = NSApplication.shared
    let delegate = AppDelegate()
    app.delegate = delegate; app.setActivationPolicy(.accessory); app.run()
}
