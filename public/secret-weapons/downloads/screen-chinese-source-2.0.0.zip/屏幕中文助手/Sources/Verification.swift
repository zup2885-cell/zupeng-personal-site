import AppKit
import WebKit

@MainActor final class Verification {
    private var web: WebTranslator?
    private var passed: [String] = []
    func run() {
        Task {
            do {
                try check(EnglishFilter.accepts("Translate this screen"), "英语识别筛选")
                try check(!EnglishFilter.accepts("本来就是中文") && !EnglishFilter.accepts("README.md") && !EnglishFilter.accepts("hello@example.com"), "中文、文件名和邮箱保护")
                try check(WebAddress.parse("example.com")?.absoluteString == "https://example.com", "网址自动补全")
                try check(WebAddress.parse("javascript:alert(1)") == nil && WebAddress.parse("file:///etc/passwd") == nil && WebAddress.parse("https://user:pass@example.com") == nil, "危险网址拒绝")
                let first = Self.scene(y: 120), moved = Self.scene(y: 240)
                let lines = try ScreenTranslator.recognize(first)
                let originalFrame = GrayFrame(first)!, movedFrame = GrayFrame(moved)!
                try check(!lines.isEmpty && !originalFrame.differs(from: originalFrame, regions: lines.map(\.rect)) && movedFrame.differs(from: originalFrame, regions: lines.map(\.rect)), "真实 Vision 坐标与原文移动检测")
                let engine = TranslationEngine(fast: true)
                let result = try await engine.translate(["The battery is fully charged.", "GitHub"])
                try check(Self.hasChinese(result[0]) && result[1] == "GitHub", "真实 Apple 本机翻译及专名保护")
                let web = WebTranslator(); self.web = web; web.demo(); web.show()
                try await until(timeout: 45) {
                    let v = try await self.evaluate("document.querySelector('#title')?.textContent || ''") as? String ?? ""
                    return Self.hasChinese(v)
                }
                try check(true, "原生网页真实英译中，无翻译接口")
                let details = try await evaluate("""
                    JSON.stringify({font:getComputedStyle(document.querySelector('#title')).fontSize,input:document.querySelector('#input').value,
                      overlays:document.querySelectorAll('[data-chinese-overlay]').length,strong:!!document.querySelector('#strong'),text:document.querySelector('#title').textContent})
                    """) as? String ?? "{}"
                let d = try JSONSerialization.jsonObject(with: Data(details.utf8)) as? [String: Any] ?? [:]
                try check(d["font"] as? String == "36px" && d["input"] as? String == "Your typed text stays unchanged" && d["overlays"] as? Int == 0 && d["strong"] as? Bool == true, "原字号、输入框及链接结构保留，无覆盖层")
                _ = try await evaluate("document.querySelector('#test-button').click(); document.querySelector('#result').textContent")
                try check((try await evaluate("document.querySelector('#result').textContent") as? String)?.contains("点击成功") == true, "译后按钮可点击")
                _ = try await evaluate("document.querySelectorAll('button')[1].click()")
                try await until { Self.hasChinese(try await self.evaluate("document.querySelector('#dynamic')?.textContent || ''") as? String ?? "") }
                try check(true, "动态新增英文自动翻译")
                _ = try await evaluate("document.querySelector('#final').scrollIntoView()")
                try await until { Self.hasChinese(try await self.evaluate("document.querySelector('#last-text').textContent") as? String ?? "") }
                try check(true, "滚动后新增可见段落自动翻译")
                web.toggleOriginal()
                try await until {
                    try await self.evaluate("document.querySelector('#title').textContent") as? String == "Understand the page, without changing your workflow."
                }
                try check((try await evaluate("document.querySelector('#dynamic').textContent") as? String) == "New content should be translated automatically.", "原文恢复及动态内容保留")
                try check((try await evaluate("document.querySelector('#rich').textContent") as? String) == "You can save changes without leaving this page.", "富文本原文及顺序恢复")
                web.toggleOriginal()
                try await until { Self.hasChinese(try await self.evaluate("document.querySelector('#last-text').textContent") as? String ?? "") }
                try check(true, "重复开关及译文缓存恢复")
                save(success: true, error: nil)
                print("PASS: \(passed.count) 组真实本机与原生网页检查。")
                NSApp.terminate(nil)
            } catch {
                save(success: false, error: error.localizedDescription)
                fputs("FAILED: \(error.localizedDescription)\n", stderr); exit(1)
            }
        }
    }
    private func check(_ okay: Bool, _ name: String) throws {
        guard okay else { throw NSError(domain: "Verification", code: 1, userInfo: [NSLocalizedDescriptionKey: name]) }
        passed.append(name); print("通过：\(name)")
    }
    private func until(timeout: Double = 20, _ condition: () async throws -> Bool) async throws {
        let end = Date().addingTimeInterval(timeout)
        repeat {
            if (try? await condition()) == true { return }
            try await Task.sleep(for: .milliseconds(150))
        } while Date() < end
        throw NSError(domain: "Verification", code: 2, userInfo: [NSLocalizedDescriptionKey: "等待网页实际翻译超时"])
    }
    private func evaluate(_ script: String) async throws -> Any {
        guard let web else { throw CocoaError(.coderInvalidValue) }
        return try await withCheckedThrowingContinuation { c in
            web.webView.evaluateJavaScript(script) { value, error in
                if let error { c.resume(throwing: error) } else { c.resume(returning: value ?? NSNull()) }
            }
        }
    }
    private static func hasChinese(_ value: String) -> Bool { value.unicodeScalars.contains { (0x3400...0x9fff).contains($0.value) } }
    private static func scene(y: CGFloat) -> CGImage {
        let image = NSImage(size: NSSize(width: 800, height: 500)); image.lockFocus()
        NSColor.white.setFill(); NSRect(x: 0, y: 0, width: 800, height: 500).fill()
        ("Translate this screen" as NSString).draw(at: NSPoint(x: 80, y: y), withAttributes: [.font: NSFont.systemFont(ofSize: 30), .foregroundColor: NSColor.black])
        image.unlockFocus(); return image.cgImage(forProposedRect: nil, context: nil, hints: nil)!
    }
    private func save(success: Bool, error: String?) {
        let args = CommandLine.arguments
        guard let index = args.firstIndex(of: "--report"), args.indices.contains(index + 1) else { return }
        let report: [String: Any] = ["success": success, "checks": passed, "error": error ?? "", "time": ISO8601DateFormatter().string(from: Date()), "testData": "仅内置虚构测试页面", "engine": "Apple Translation installed-source local model"]
        if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) { try? data.write(to: URL(fileURLWithPath: args[index + 1]), options: .atomic) }
    }
}
