import AppKit
import WebKit

@MainActor final class WebTranslator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandlerWithReply, NSWindowDelegate {
    static let world = WKContentWorld.world(name: "ScreenChinesePrivateWorld")
    let window: NSWindow
    let webView: WKWebView
    let address = NSTextField()
    let status = NSTextField(labelWithString: "网页加载后自动翻译 · 本机英译中")
    private let originalButton = NSButton(title: "查看原文", target: nil, action: nil)
    private let backButton = NSButton(title: "后退", target: nil, action: nil)
    private let forwardButton = NSButton(title: "前进", target: nil, action: nil)
    private let engine = TranslationEngine()
    private var enabled = true
    private var previous: Task<Void, Never>?
    private var pending = 0
    var onVisibility: (() -> Void)?
    var onNeedsLanguage: (() -> Void)?
    private(set) var translatedCount = 0
    override init() {
        let configuration = WKWebViewConfiguration()
        // The handler and translation engine are inaccessible to webpage scripts.
        let controller = WKUserContentController()
        configuration.userContentController = controller
        configuration.websiteDataStore = .nonPersistent()
        webView = WKWebView(frame: .zero, configuration: configuration)
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1080, height: 760), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        super.init()
        window.title = "屏幕中文助手 · 网页翻译"
        window.minSize = NSSize(width: 750, height: 460)
        window.isReleasedWhenClosed = false; window.delegate = self; window.center()
        webView.navigationDelegate = self; webView.uiDelegate = self
        controller.addScriptMessageHandler(self, contentWorld: Self.world, name: "translate")
        installScripts()
        buildLayout()
        showHome()
    }
    private func button(_ title: String, _ action: Selector, tooltip: String? = nil) -> NSButton {
        let button = NSButton(title: title, target: self, action: action)
        button.bezelStyle = .rounded; button.toolTip = tooltip
        return button
    }
    private func buildLayout() {
        address.placeholderString = "粘贴网址，按回车自动译成中文"
        address.font = .systemFont(ofSize: 13); address.target = self; address.action = #selector(navigate)
        address.setContentHuggingPriority(.defaultLow, for: .horizontal)
        backButton.target = self; backButton.action = #selector(goBack)
        forwardButton.target = self; forwardButton.action = #selector(goForward)
        originalButton.target = self; originalButton.action = #selector(toggleOriginal)
        let toolbar = NSStackView(views: [backButton, forwardButton, button("首页", #selector(home)), address,
            button("粘贴网址", #selector(pasteURL)), originalButton, button("重试", #selector(retry))])
        toolbar.orientation = .horizontal; toolbar.spacing = 8
        toolbar.edgeInsets = NSEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
        status.font = .systemFont(ofSize: 11); status.textColor = .secondaryLabelColor
        status.lineBreakMode = .byTruncatingTail
        let footer = NSStackView(views: [status, button("功能测试页", #selector(demo))])
        footer.orientation = .horizontal; footer.edgeInsets = NSEdgeInsets(top: 5, left: 14, bottom: 5, right: 12)
        status.setContentHuggingPriority(.defaultLow, for: .horizontal)
        let content = NSView()
        for view in [toolbar, webView, footer] { view.translatesAutoresizingMaskIntoConstraints = false; content.addSubview(view) }
        NSLayoutConstraint.activate([
            toolbar.topAnchor.constraint(equalTo: content.topAnchor), toolbar.leadingAnchor.constraint(equalTo: content.leadingAnchor), toolbar.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            address.widthAnchor.constraint(greaterThanOrEqualToConstant: 200),
            webView.topAnchor.constraint(equalTo: toolbar.bottomAnchor), webView.leadingAnchor.constraint(equalTo: content.leadingAnchor), webView.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            footer.topAnchor.constraint(equalTo: webView.bottomAnchor), footer.leadingAnchor.constraint(equalTo: content.leadingAnchor), footer.trailingAnchor.constraint(equalTo: content.trailingAnchor), footer.bottomAnchor.constraint(equalTo: content.bottomAnchor)
        ])
        window.contentView = content
    }
    private func installScripts() {
        guard let url = Bundle.main.url(forResource: "translate", withExtension: "js"), let source = try? String(contentsOf: url, encoding: .utf8) else { return }
        let prefix = """
        globalThis.__chineseBridge = {
          enabled: \(enabled ? "true" : "false"),
          translate: units => webkit.messageHandlers.translate.postMessage({type:'translate',units}),
          status: data => webkit.messageHandlers.translate.postMessage({type:'status',data}).catch(()=>{})
        };
        """
        let controller = webView.configuration.userContentController
        controller.removeAllUserScripts()
        controller.addUserScript(WKUserScript(source: prefix + source, injectionTime: .atDocumentEnd, forMainFrameOnly: false, in: Self.world))
    }
    func show() { window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true); onVisibility?() }
    func showHome() {
        guard let url = Bundle.main.url(forResource: "home", withExtension: "html") else { return }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        address.stringValue = ""
    }
    @objc private func home() { showHome() }
    @objc func demo() {
        guard let url = Bundle.main.url(forResource: "demo", withExtension: "html") else { return }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }
    @objc private func goBack() { webView.goBack() }
    @objc private func goForward() { webView.goForward() }
    @objc private func navigate() { loadAddress(address.stringValue) }
    func loadAddress(_ value: String) {
        guard let url = WebAddress.parse(value) else { status.stringValue = "请输入完整网址，例如 https://example.com"; return }
        address.stringValue = url.absoluteString
        webView.load(URLRequest(url: url))
    }
    @objc private func pasteURL() {
        guard let value = NSPasteboard.general.string(forType: .string), WebAddress.parse(value) != nil else {
            status.stringValue = "剪贴板里没有网址，请先复制地址栏中的网页地址。"; return
        }
        loadAddress(value)
    }
    @objc func toggleOriginal() {
        enabled.toggle(); originalButton.title = enabled ? "查看原文" : "显示中文"
        installScripts()
        webView.evaluateJavaScript("globalThis.ChinesePage?.setEnabled(\(enabled ? "true" : "false"))", in: nil, in: Self.world) { _ in }
    }
    @objc private func retry() {
        webView.evaluateJavaScript("globalThis.ChinesePage?.retry()", in: nil, in: Self.world) { _ in }
        status.stringValue = "正在重新翻译…"
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        translatedCount = 0; status.stringValue = "正在打开网页…"
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        address.stringValue = webView.url?.isFileURL == false ? webView.url?.absoluteString ?? "" : ""
        backButton.isEnabled = webView.canGoBack; forwardButton.isEnabled = webView.canGoForward
        status.stringValue = enabled ? "正在识别可见英文…" : "正在显示原文"
        window.title = "\(webView.title ?? "网页翻译") · 屏幕中文助手"
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { status.stringValue = "网页未能打开：\(error.localizedDescription)" }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { self.webView(webView, didFailProvisionalNavigation: navigation, withError: error) }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.scheme == "screenchinese" {
            if url.host == "demo" { demo() }
            decisionHandler(.cancel); return
        }
        let ownFile = url.isFileURL && ["home.html", "demo.html"].contains(url.lastPathComponent) && url.standardizedFileURL.deletingLastPathComponent().path == Bundle.main.resourceURL?.standardizedFileURL.path
        if ["https", "http", "about"].contains(url.scheme ?? "") || ownFile { decisionHandler(.allow) }
        else { status.stringValue = "此链接需要由对应应用打开。"; decisionHandler(.cancel) }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url, ["http", "https"].contains(url.scheme ?? "") { webView.load(navigationAction.request) }
        return nil
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
        guard let body = message.body as? [String: Any], let type = body["type"] as? String else { replyHandler(nil, "无效请求"); return }
        if type == "status" {
            if message.frameInfo.isMainFrame, let data = body["data"] as? [String: Any] {
                let state = data["state"] as? String ?? ""
                translatedCount = data["count"] as? Int ?? 0
                status.stringValue = state == "translating" ? "正在本机翻译… · 已处理 \(translatedCount) 处" : state == "error" ? "翻译暂不可用，检查语言包后点击重试。" : state == "original" ? "正在显示原文" : "中文已更新 · \(translatedCount) 处 · 滚动时继续翻译"
            }
            replyHandler(["ok": true], nil); return
        }
        guard type == "translate", let raw = body["units"], let data = try? JSONSerialization.data(withJSONObject: raw), data.count <= 160000,
              let units = try? JSONDecoder().decode([[WebSegment]].self, from: data), !units.isEmpty, units.count <= 16,
              units.allSatisfy({ !$0.isEmpty && $0.count <= 48 && $0.reduce(0, { $0 + $1.text.utf8.count }) <= 32000 }), pending < 8 else {
            replyHandler(nil, "翻译内容超出单次限制，请稍后重试。"); return
        }
        pending += 1
        let earlier = previous
        previous = Task { [weak self] in
            await earlier?.value
            guard let self else { replyHandler(nil, "窗口已关闭"); return }
            defer { self.pending -= 1 }
            do {
                let result = try await self.engine.translateUnits(units)
                let data = try JSONEncoder().encode(result)
                replyHandler(["units": try JSONSerialization.jsonObject(with: data)], nil)
            } catch {
                replyHandler(nil, "本机语言包尚未就绪或翻译中断，请在菜单中检查语言包。")
            }
        }
    }
    func windowDidBecomeKey(_ notification: Notification) { onVisibility?() }
    func windowWillClose(_ notification: Notification) { onVisibility?() }
}

enum WebAddress {
    static func parse(_ text: String) -> URL? {
        var value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, !value.contains(where: { $0.isWhitespace }) else { return nil }
        if !value.contains("://") { value = "https://" + value }
        guard let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""), let host = url.host, !host.isEmpty, url.user == nil, url.password == nil else { return nil }
        return url
    }
}
