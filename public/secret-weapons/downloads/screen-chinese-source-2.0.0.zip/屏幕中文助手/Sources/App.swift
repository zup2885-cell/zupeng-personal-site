import AppKit
import SwiftUI
import ServiceManagement

final class FloatingButton: NSButton {
    override func mouseDown(with event: NSEvent) {
        guard let window else { return }
        let origin = window.frame.origin, pointer = NSEvent.mouseLocation
        var moved = false
        while let next = window.nextEvent(matching: [.leftMouseDragged, .leftMouseUp]) {
            let current = NSEvent.mouseLocation
            let dx = current.x - pointer.x, dy = current.y - pointer.y
            if next.type == .leftMouseDragged {
                if hypot(dx, dy) > 3 { moved = true }
                if moved { window.setFrameOrigin(NSPoint(x: origin.x + dx, y: origin.y + dy)) }
            } else {
                if !moved { performClick(nil) }
                let point = window.frame.origin
                UserDefaults.standard.set([point.x, point.y], forKey: "chineseWidgetPosition")
                return
            }
        }
    }
}

@MainActor final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    let languages = LanguageModel()
    let screen = ScreenTranslator()
    var widget: NSPanel!
    var statusItem: NSStatusItem!
    var web: WebTranslator?
    var languageWindow: NSWindow?
    var stateItem: NSMenuItem!
    var loginItem: NSMenuItem!
    private var diagnosticTimer: Timer?
    private var verification: Verification?
    private var startedAutomatically = false
    func applicationDidFinishLaunching(_ notification: Notification) {
        if CommandLine.arguments.contains("--verify") {
            verification = Verification(); verification?.run(); return
        }
        UserDefaults.standard.register(defaults: ["chineseLaunchAtLogin": true])
        buildMenu(); buildWidget()
        screen.suppressForOwnWindow = { [weak self] in self?.web?.window.isKeyWindow == true || self?.languageWindow?.isKeyWindow == true }
        screen.statusChanged = { [weak self] message in self?.stateItem.title = message; self?.writeStatus() }
        languages.onReady = { [weak self] in
            self?.languageWindow?.orderOut(nil)
            if let self, !self.startedAutomatically, CGPreflightScreenCaptureAccess() {
                self.startedAutomatically = true; self.screen.start(screen: self.widget.screen ?? NSScreen.main)
            }
        }
        Task {
            await languages.check()
            if !languages.ready { showLanguages() }
            if UserDefaults.standard.bool(forKey: "chineseLaunchAtLogin") { try? SMAppService.mainApp.register() }
            writeStatus()
        }
        diagnosticTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in MainActor.assumeIsolated { self?.writeStatus() } }
        if CommandLine.arguments.contains("--demo") { showDemo() }
        else if CommandLine.arguments.contains("--web") { showWeb() }
    }
    private func item(_ title: String, _ action: Selector) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: ""); item.target = self; return item
    }
    private func buildMenu() {
        let menu = NSMenu(); menu.delegate = self
        menu.addItem(item("打开网页翻译…", #selector(showWeb)))
        menu.addItem(item("功能演示", #selector(showDemo)))
        menu.addItem(.separator())
        menu.addItem(item("开始／暂停屏幕翻译", #selector(toggleScreen)))
        stateItem = NSMenuItem(title: "正在检查本机翻译…", action: nil, keyEquivalent: ""); menu.addItem(stateItem)
        menu.addItem(item("屏幕录制权限…", #selector(permission)))
        menu.addItem(item("检查语言包…", #selector(showLanguages)))
        menu.addItem(item("显示悬浮按钮", #selector(showWidget)))
        loginItem = item("登录时自动启动", #selector(toggleLogin)); menu.addItem(loginItem)
        menu.addItem(.separator()); menu.addItem(item("退出", #selector(quit)))
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.image = NSImage(systemSymbolName: "character.bubble", accessibilityDescription: "屏幕中文助手")
        statusItem.menu = menu
        let main = NSMenu(); let app = NSMenuItem(); app.submenu = menu.copy() as? NSMenu; app.submenu?.delegate = self; main.addItem(app)
        let edit = NSMenuItem(title: "编辑", action: nil, keyEquivalent: ""); let editMenu = NSMenu(title: "编辑")
        for (name, action, key) in [("撤销", "undo:", "z"), ("剪切", "cut:", "x"), ("复制", "copy:", "c"), ("粘贴", "paste:", "v"), ("全选", "selectAll:", "a")] { editMenu.addItem(NSMenuItem(title: name, action: NSSelectorFromString(action), keyEquivalent: key)) }
        edit.submenu = editMenu; main.addItem(edit); NSApp.mainMenu = main
    }
    private func buildWidget() {
        widget = NSPanel(contentRect: NSRect(x: 80, y: 160, width: 46, height: 46), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        widget.title = "屏幕中文助手 · 悬浮按钮"; widget.isOpaque = false; widget.backgroundColor = .clear
        widget.level = .floating; widget.hasShadow = true; widget.isMovableByWindowBackground = true
        widget.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        let button = FloatingButton(frame: NSRect(x: 3, y: 3, width: 40, height: 40))
        button.isBordered = false; button.image = NSImage(systemSymbolName: "character.bubble.fill", accessibilityDescription: "屏幕翻译")
        button.imageScaling = .scaleProportionallyUpOrDown; button.contentTintColor = .systemBlue
        button.target = self; button.action = #selector(toggleScreen); button.menu = statusItem.menu
        button.toolTip = "点击开始或暂停屏幕翻译；右键打开网页翻译；按住拖动。"
        button.setAccessibilityLabel("屏幕翻译，右键打开菜单")
        widget.contentView?.addSubview(button)
        if let p = UserDefaults.standard.array(forKey: "chineseWidgetPosition") as? [Double], p.count == 2 { widget.setFrameOrigin(NSPoint(x: p[0], y: p[1])) }
        showWidget()
    }
    @objc func showWidget() {
        if !NSScreen.screens.contains(where: { $0.visibleFrame.intersects(widget.frame) }), let screen = NSScreen.main { widget.setFrameOrigin(NSPoint(x: screen.visibleFrame.maxX - 80, y: screen.visibleFrame.minY + 160)) }
        widget.orderFrontRegardless()
    }
    private func makeWeb() -> WebTranslator {
        if let web { return web }
        let result = WebTranslator(); result.onVisibility = { [weak self] in self?.screen.invalidate() }
        web = result; return result
    }
    @objc func showWeb() { makeWeb().show() }
    @objc func showDemo() { let web = makeWeb(); web.demo(); web.show() }
    @objc func toggleScreen() {
        if screen.active { screen.stop() }
        else if !languages.ready { showLanguages() }
        else if !CGPreflightScreenCaptureAccess() { permission() }
        else { screen.start(screen: widget.screen ?? NSScreen.main) }
        writeStatus()
    }
    @objc func permission() {
        if CGPreflightScreenCaptureAccess() {
            stateItem.title = "屏幕录制已授权"; return
        }
        let alert = NSAlert(); alert.messageText = "允许读取屏幕，才能翻译其他软件"
        alert.informativeText = "识别和翻译在本机完成，不保存或上传屏幕截图。系统授权只需设置一次；网页翻译窗口无需录屏权限。"
        alert.addButton(withTitle: "打开系统授权"); alert.addButton(withTitle: "先用网页翻译")
        NSApp.activate(ignoringOtherApps: true)
        if alert.runModal() == .alertFirstButtonReturn {
            _ = CGRequestScreenCaptureAccess()
            NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture")!)
        } else { showWeb() }
    }
    @objc func showLanguages() {
        if languageWindow == nil {
            let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 482, height: 280), styleMask: [.titled, .closable], backing: .buffered, defer: false)
            window.title = "本机翻译准备"; window.isReleasedWhenClosed = false
            window.contentView = NSHostingView(rootView: LanguageView(model: languages)); window.center(); languageWindow = window
        }
        languageWindow?.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
        Task { await languages.check() }
    }
    @objc func toggleLogin() {
        let service = SMAppService.mainApp
        if service.status == .requiresApproval { SMAppService.openSystemSettingsLoginItems(); return }
        let enabled = service.status != .enabled
        do {
            if enabled { try service.register() } else { try service.unregister() }
            UserDefaults.standard.set(enabled, forKey: "chineseLaunchAtLogin")
        } catch { stateItem.title = "自启设置未完成：\(error.localizedDescription)" }
        writeStatus()
    }
    func menuWillOpen(_ menu: NSMenu) {
        loginItem?.state = SMAppService.mainApp.status == .enabled ? .on : SMAppService.mainApp.status == .requiresApproval ? .mixed : .off
        loginItem?.title = SMAppService.mainApp.status == .requiresApproval ? "登录自启：需要在系统设置允许…" : "登录时自动启动"
    }
    private func writeStatus() {
        var state = screen.diagnostic
        state["languageReady"] = languages.ready; state["webTranslatedCount"] = web?.translatedCount ?? 0
        state["webWindowVisible"] = web?.window.isVisible ?? false
        state["loginEnabled"] = SMAppService.mainApp.status == .enabled
        state["pid"] = ProcessInfo.processInfo.processIdentifier
        state["time"] = Date().timeIntervalSince1970
        let directory = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/ScreenChineseAssistant")
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if let data = try? JSONSerialization.data(withJSONObject: state, options: [.sortedKeys]) { try? data.write(to: directory.appendingPathComponent("status.json"), options: .atomic) }
    }
    @objc func quit() { screen.stop(); NSApp.terminate(nil) }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { showWeb(); return true }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
    func applicationWillTerminate(_ notification: Notification) { diagnosticTimer?.invalidate(); screen.stop() }
}
