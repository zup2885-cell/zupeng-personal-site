import AppKit
final class Fixture: NSObject, NSApplicationDelegate, NSTextFieldDelegate {
    var window: NSWindow!
    var button: NSButton!
    var result: NSTextField!
    var clicks = 0
    func applicationDidFinishLaunching(_ notification: Notification) {
        window = NSWindow(contentRect: NSRect(x: 100, y: 100, width: 980, height: 740), styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
        window.title = "屏幕翻译测试窗口 · 虚构内容"; window.center()
        let scroll = NSScrollView(frame: window.contentLayoutRect); scroll.autoresizingMask = [.width,.height]; scroll.hasVerticalScroller = true
        let doc = NSView(frame: NSRect(x: 0, y: 0, width: 920, height: 2500))
        for i in 0..<25 {
            let field = NSTextField(labelWithString: i == 0 ? "SCREEN TRANSLATION TEST" : "Section \(i): Keep your camera ready and check the sound.")
            field.font = .systemFont(ofSize: i == 0 ? 26 : 19); field.frame = NSRect(x: 40, y: 2400 - i * 88, width: 830, height: 36); doc.addSubview(field)
        }
        result = NSTextField(labelWithString: "虚构测试 · 点击按钮可验证中文层是否挡鼠标"); result.frame = NSRect(x: 40, y: 2356, width: 800, height: 24); doc.addSubview(result)
        button = NSButton(title: "Confirm this button", target: self, action: #selector(clicked)); button.frame = NSRect(x: 40, y: 2318, width: 220, height: 32); doc.addSubview(button)
        let input = NSTextField(frame: NSRect(x: 300, y: 2318, width: 400, height: 32)); input.placeholderString = "Type here"; input.delegate = self; doc.addSubview(input)
        scroll.documentView = doc; window.contentView = scroll
        doc.scroll(NSPoint(x: 0, y: 2500 - scroll.contentSize.height))
        window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true); save()
    }
    @objc func clicked() { clicks += 1; result.stringValue = "点击成功 \(clicks) 次 · 中文层不挡鼠标"; save() }
    func controlTextDidChange(_ obj: Notification) { save(typed: (obj.object as? NSTextField)?.stringValue.count ?? 0) }
    func save(typed: Int = 0) {
        let args = CommandLine.arguments
        guard let i = args.firstIndex(of: "--report"), args.indices.contains(i+1) else { return }
        let data = try! JSONSerialization.data(withJSONObject: ["clicks":clicks,"typedCount":typed])
        try? data.write(to: URL(fileURLWithPath: args[i+1]), options: .atomic)
    }
}
let app = NSApplication.shared; let fixture = Fixture(); app.delegate = fixture; app.setActivationPolicy(.regular); app.run()
