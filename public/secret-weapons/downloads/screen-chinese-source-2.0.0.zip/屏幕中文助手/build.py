#!/usr/bin/env python3
"""Build a standalone native Mac app; keep the stable local screen-permission identity."""
from pathlib import Path
import argparse,json,platform,plistlib,subprocess,shutil,zipfile

ROOT=Path(__file__).resolve().parent
def run(*args):subprocess.run([str(x) for x in args],cwd=ROOT,check=True)
def sdk():
    versions=[]
    for p in Path('/Library/Developer/CommandLineTools/SDKs').glob('MacOSX*.sdk'):
        import re
        m=re.fullmatch(r'MacOSX(\d+)\.(\d+)\.sdk',p.resolve().name)
        if m and 26<=int(m[1])<=int(platform.mac_ver()[0].split('.')[0]):versions.append(((int(m[1]),int(m[2])),p.resolve()))
    if not versions:raise RuntimeError('需要 macOS 26 SDK')
    return max(versions)[1]
def build(install=False):
    identity_path=Path.home()/'Library/Application Support/ClipShelfBuildSigning/identity.json'
    if not identity_path.exists():raise RuntimeError('缺少已有固定签名身份；不会改用导致权限失效的临时签名。')
    identity=json.loads(identity_path.read_text())
    app=ROOT/'build/屏幕中文助手.app'
    binary=app/'Contents/MacOS';resources=app/'Contents/Resources'
    binary.mkdir(parents=True,exist_ok=True);resources.mkdir(parents=True,exist_ok=True)
    run('xcrun','swiftc','-sdk',sdk(),'-swift-version','5','-O','-target',('arm64' if platform.machine()=='arm64' else 'x86_64')+'-apple-macosx26.0',
        '-framework','Cocoa','-framework','SwiftUI','-framework','WebKit','-framework','Translation','-framework','Vision','-framework','ScreenCaptureKit','-framework','ServiceManagement',
        *sorted((ROOT/'Sources').glob('*.swift')),'-o',binary/'ScreenChinese')
    for p in (ROOT/'Resources').iterdir():shutil.copy2(p,resources/p.name)
    shutil.copy2(ROOT/'README.md',resources/'使用说明.md')
    info=dict(CFBundleIdentifier='local.azu.screentranslate',CFBundleName='屏幕中文助手',CFBundleDisplayName='屏幕中文助手',CFBundleExecutable='ScreenChinese',CFBundlePackageType='APPL',
        CFBundleShortVersionString='2.0.0',CFBundleVersion='20',LSUIElement=True,LSMinimumSystemVersion='26.0',NSHighResolutionCapable=True,
        NSScreenCaptureUsageDescription='识别屏幕英文并在本机翻译成中文。不保存或上传屏幕截图。',NSAppTransportSecurity={'NSAllowsArbitraryLoadsInWebContent':True})
    (app/'Contents/Info.plist').write_bytes(plistlib.dumps(info))
    requirement='identifier "local.azu.screentranslate" and certificate leaf = H"'+identity['sha1']+'"'
    run('codesign','--force','--sign',identity['sha1'],'--keychain',identity['keychain'],'--identifier','local.azu.screentranslate','--requirements','=designated => '+requirement,app)
    run('codesign','--verify','--deep','--strict','--test-requirement','='+requirement,app)
    run('ditto','-c','-k','--keepParent',app,ROOT/'build/屏幕中文助手-Mac.zip')
    if install:
        target=Path.home()/'Applications/屏幕中文助手.app'
        if target.exists():
            previous=ROOT/'build/previous-installed.app'
            if previous.exists():shutil.rmtree(previous)
            shutil.move(str(target),previous)
        run('ditto',app,target)
        print('已安装：',target)
    print('已构建：',app)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--install',action='store_true');args=parser.parse_args();build(args.install)
