(() => {
  'use strict';
  const bridge = globalThis.__chineseBridge;
  if (!bridge || globalThis.ChinesePage) return;
  const skip = 'script,style,noscript,textarea,input,select,option,pre,code,kbd,samp,svg,math,[contenteditable]:not([contenteditable="false"]),[translate="no"],.notranslate';
  const blocks = 'p,li,h1,h2,h3,h4,h5,h6,figcaption,button,div';
  const inline = new Set(['A', 'SPAN', 'B', 'STRONG', 'I', 'EM', 'U', 'SMALL', 'S', 'MARK']);
  const records = new Map(), cache = new Map(), unsafe = new WeakSet();
  let enabled = bridge.enabled, busy = false, generation = 0, failures = 0, timer;
  let pointer = null, walker = null, translated = 0;
  const protect = text => /^(?:https?:\/\/|www\.|[\w.+-]+@[\w.-]+\.[a-z]{2,})/i.test(text.trim()) ||
    /^(?:GitHub|GitLab|Google|Chrome|Safari|Microsoft|OpenAI|ChatGPT|Apple|macOS|iOS)$/i.test(text.trim()) ||
    /^(?:git|npm|npx|python[23]?|pip[23]?|node|swift|brew)\s+[-\w/.]/i.test(text.trim()) ||
    (!/\s/.test(text.trim()) && /[a-z]/i.test(text) && /[\d_/\\]|\.[a-z\d]{1,8}$/i.test(text));
  function english(text) {
    return !protect(text) && (text.match(/[a-z]/gi) || []).length >= 2 &&
      (text.match(/[a-z]/gi) || []).length > (text.match(/[\u3400-\u9fff]/g) || []).length * 3 && text.length <= 8000;
  }
  function eligible(node) {
    const parent = node.parentElement;
    if (!parent || !node.isConnected || parent.closest(skip)) return false;
    const range = document.createRange(); range.selectNodeContents(node);
    const visible = [...range.getClientRects()].some(r => r.width > 0 && r.height > 0 && r.bottom > -120 && r.top < innerHeight + 350 && r.right > 0 && r.left < innerWidth);
    range.detach();
    if (!visible) return false;
    const style = getComputedStyle(parent);
    return style.display !== 'none' && style.visibility !== 'hidden';
  }
  const same = (root, children) => root.childNodes.length === children.length && children.every((n, i) => root.childNodes[i] === n);
  const style = e => { const s = getComputedStyle(e); return [s.fontSize,s.fontFamily,s.fontWeight,s.fontStyle,s.color,s.lineHeight,s.letterSpacing].join('|'); };
  function unitFor(node) {
    const root = node.parentElement.closest(blocks);
    if (root && !unsafe.has(root) && !records.has(root)) {
      const children = [...root.childNodes], nodes = [];
      let safe = children.length > 1 && children.length <= 40;
      for (const child of children) {
        if (child.nodeType === Node.TEXT_NODE) nodes.push(child);
        else if (child.nodeType === Node.ELEMENT_NODE && inline.has(child.tagName) && child.childNodes.length === 1 && child.firstChild.nodeType === Node.TEXT_NODE && !child.closest(skip)) nodes.push(child.firstChild);
        else { safe = false; break; }
      }
      if (safe && nodes.includes(node) && english(nodes.map(n => n.data).join(''))) return {key:root,root,children,nodes,original:nodes.map(n => n.data)};
    }
    return english(node.data) ? {key:node,nodes:[node],original:[node.data]} : null;
  }
  const unchanged = u => u.nodes.every((n, i) => n.isConnected && n.data === u.original[i]) && (!u.root || same(u.root, u.children));
  const owned = r => r.expected.every(([n,t]) => n.isConnected && n.data === t) && (!r.root || same(r.root,r.translatedChildren));
  function restore(r) {
    const expected = new Map(r.expected);
    r.nodes.forEach((n,i) => { if(n.isConnected && n.data === expected.get(n)) n.data = r.original[i]; });
    for (const n of r.created || []) if(n.isConnected && n.data === expected.get(n)) n.remove();
    if(r.root && same(r.root,r.translatedChildren.filter(n => !(r.created || []).includes(n)))) r.root.replaceChildren(...r.children);
  }
  function apply(u,result) {
    if(!enabled || !unchanged(u) || !u.nodes.some(eligible) || !Array.isArray(result?.runs)) return;
    const selection = document.getSelection();
    if(u.root && (u.root.contains(document.activeElement) || (pointer && u.root.contains(pointer)) || (selection && !selection.isCollapsed && selection.containsNode(u.root,true)))) return;
    const runs = result.runs;
    if(!runs.length || runs.some(r => !Number.isInteger(r.node) || !u.nodes[r.node] || typeof r.text !== 'string')) return;
    const r = {...u,expected:[],created:[]};
    if(!u.root || !result.contextual) {
      u.nodes.forEach((n,i) => {
        const t = runs.filter(x => x.node === i).map(x => x.text).join('').trim();
        n.data = t ? u.original[i].match(/^\s*/)[0]+t+u.original[i].match(/\s*$/)[0] : u.original[i];
        r.expected.push([n,n.data]);
      });
      r.translatedChildren = u.children;
    } else {
      const elements = u.nodes.map(n => n.parentElement === u.root ? null : n.parentElement);
      if(elements.some((e,i) => e && runs.filter(x => x.node === i).length !== 1)) return;
      const before = elements.map(e => e && style(e)), used = new Set(), children = [];
      for(const run of runs) {
        let n = u.nodes[run.node];
        if(used.has(run.node)) { n = document.createTextNode(''); r.created.push(n); }
        used.add(run.node); n.data = run.text; r.expected.push([n,n.data]); children.push(elements[run.node] || n);
      }
      u.nodes.forEach((n,i) => { if(!used.has(i)) { n.data=''; r.expected.push([n,'']); children.push(elements[i] || n); } });
      u.root.replaceChildren(...children); r.translatedChildren = [...u.root.childNodes];
      if(elements.some((e,i) => e && style(e) !== before[i])) { restore(r); unsafe.add(u.root); return; }
    }
    records.set(u.key,r); translated++;
  }
  function status(state,error='') {
    if(self === top) bridge.status({state,count:records.size,error});
  }
  function schedule(delay=120) {
    clearTimeout(timer);
    if(enabled && !document.hidden && failures < 5) timer = setTimeout(scan,delay);
  }
  async function scan() {
    if(!enabled || busy || document.hidden) return;
    const version = generation;
    for(const [key,r] of records) {
      if(!key.isConnected) { records.delete(key); continue; }
      if(!owned(r)) { restore(r); records.delete(key); if(r.root) unsafe.add(r.root); }
    }
    const seen = new Set([...records.values()].flatMap(r => r.nodes.concat(r.created || [])));
    if(!walker) walker = document.createTreeWalker(document.body || document.documentElement,NodeFilter.SHOW_TEXT);
    const batch=[], consumed=new Set();
    let walked=0, node;
    while(batch.length < 12 && walked++ < 6000 && (node=walker.nextNode())) {
      if(seen.has(node) || !english(node.data) || !eligible(node)) continue;
      const u=unitFor(node);
      if(!u || consumed.has(u.key)) continue;
      consumed.add(u.key);
      u.segments=u.nodes.map((n,i) => ({text:u.original[i],plain:!u.root || n.parentElement===u.root,protected:protect(u.original[i])}));
      u.cacheKey=JSON.stringify(u.segments);
      if(cache.has(u.cacheKey)) { apply(u,cache.get(u.cacheKey)); continue; }
      batch.push(u);
    }
    const continuation=!!node;
    if(!continuation) walker=null;
    if(!batch.length) { status(enabled?'ready':'original'); if(continuation) schedule(40); return; }
    busy=true; status('translating');
    try {
      const response=await bridge.translate(batch.map(u=>u.segments));
      if(response?.error || response?.units?.length!==batch.length) throw Error(response?.error || '翻译响应不完整');
      if(version!==generation || !enabled) return;
      response.units.forEach((r,i)=> { cache.set(batch[i].cacheKey,r); apply(batch[i],r); });
      failures=0; status('ready');
      if(cache.size>2000) { const latest=[...cache].slice(-1000); cache.clear(); latest.forEach(([a,b])=>cache.set(a,b)); }
    } catch(error) { failures++; status('error',String(error.message || error)); }
    finally { busy=false; schedule(failures?Math.min(12000,failures*1500):40); }
  }
  function setEnabled(value) {
    enabled=!!value; generation++; failures=0; clearTimeout(timer); walker=null;
    if(!enabled) { for(const r of records.values()) restore(r); records.clear(); status('original'); }
    else schedule(30);
    for(let i=0;i<frames.length;i++) frames[i].postMessage({screenChineseEnabled:enabled},'*');
  }
  addEventListener('message',event=> {
    if(self!==top && event.source===parent && typeof event.data?.screenChineseEnabled==='boolean') setEnabled(event.data.screenChineseEnabled);
  });
  globalThis.ChinesePage={setEnabled,retry:()=>setEnabled(enabled),stats:()=>({enabled,count:records.size,busy,failures,translated})};
  new MutationObserver(()=>schedule()).observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  addEventListener('scroll',()=> { walker=null; schedule(60); },{passive:true});
  addEventListener('resize',()=> {walker=null;schedule();});
  document.addEventListener('visibilitychange',()=> {if(!document.hidden)schedule();});
  document.addEventListener('pointerdown',e=> {pointer=e.target;},true);
  for(const type of ['pointerup','pointercancel']) document.addEventListener(type,()=> {pointer=null;walker=null;schedule();},true);
  document.addEventListener('focusout',()=> {walker=null;schedule();},true);
  document.addEventListener('selectionchange',()=> {if(document.getSelection()?.isCollapsed){walker=null;schedule();}});
  setEnabled(enabled);
})();
