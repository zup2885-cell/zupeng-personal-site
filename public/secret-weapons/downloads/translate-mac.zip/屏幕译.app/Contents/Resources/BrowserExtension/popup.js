const toggle = document.querySelector('#enabled');
chrome.storage.local.get({ enabled: true }).then(settings => { toggle.checked = settings.enabled; });
toggle.addEventListener('change', () => chrome.storage.local.set({ enabled: toggle.checked }));
chrome.runtime.sendMessage({ type: 'status' }).then(response => {
  document.querySelector('#status').textContent = response?.ready ? '已连接 · 本机离线翻译' : (response?.error ? '请先安装配套本机连接，并打开屏幕译准备语言包。' : '请在屏幕译中准备英语和中文语言包。');
}).catch(() => { document.querySelector('#status').textContent = '本机连接暂不可用。'; });
