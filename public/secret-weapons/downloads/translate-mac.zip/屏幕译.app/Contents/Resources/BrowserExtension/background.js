let port;
let nextID = 0;
const pending = new Map();
let queue = Promise.resolve();

function connect() {
  if (port) return port;
  const connection = chrome.runtime.connectNative('local.azu.screentranslate.browser');
  port = connection;
  connection.onMessage.addListener(message => {
    const item = pending.get(message.id);
    if (!item) return;
    pending.delete(message.id);
    clearTimeout(item.timer);
    if (message.error) item.reject(new Error(message.error));
    else item.resolve(message);
  });
  connection.onDisconnect.addListener(() => {
    const error = chrome.runtime.lastError?.message || 'Mac translator disconnected';
    if (port === connection) port = undefined;
    for (const item of pending.values()) { clearTimeout(item.timer); item.reject(new Error(error)); }
    pending.clear();
  });
  return connection;
}

function nativeRequest(payload) {
  return new Promise((resolve, reject) => {
    const id = String(++nextID);
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error('Translation timed out'));
      if (port) { port.disconnect(); port = undefined; }
    }, 30000);
    pending.set(id, { resolve, reject, timer });
    try { connect().postMessage({ ...payload, id }); }
    catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (message.type === 'pageVisibility') {
    if (sender.frameId !== 0 || typeof message.active !== 'boolean' || !['chrome','edge'].includes(message.browser)) { sendResponse({ok:false}); return false; }
    if (!message.active && !port) { sendResponse({ok:true}); return false; }
    nativeRequest({ type:'pageVisibility', active:message.active, browser:message.browser })
      .then(sendResponse, () => sendResponse({ok:false}));
    return true;
  }
  if (message.type === 'translateUnits') {
    if (!Array.isArray(message.units) || message.units.length > 24 || message.units.some(unit => !Array.isArray(unit) || !unit.length || unit.length > 48 || unit.some(segment => typeof segment?.text !== 'string' || segment.text.length > 8000 || typeof segment.plain !== 'boolean' || typeof segment.protected !== 'boolean'))) {
      sendResponse({ error: 'Invalid rich text batch' }); return false;
    }
    queue = queue.catch(() => {}).then(() => nativeRequest({ type: 'translateUnits', units: message.units }));
    queue.then(sendResponse, error => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'translate') {
    if (!Array.isArray(message.texts) || message.texts.length > 24 || message.texts.some(s => typeof s !== 'string' || s.length > 8000)) {
      sendResponse({ error: 'Invalid batch' }); return false;
    }
    queue = queue.catch(() => {}).then(() => nativeRequest({ texts: message.texts }));
    queue.then(sendResponse, error => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'status') {
    queue = queue.catch(() => {}).then(() => nativeRequest({ type: 'status' }));
    queue.then(sendResponse, error => sendResponse({ error: error.message }));
    return true;
  }
  return false;
});
