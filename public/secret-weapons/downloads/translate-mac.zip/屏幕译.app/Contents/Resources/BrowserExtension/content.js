(() => {
  const skip = 'script,style,noscript,textarea,input,select,option,pre,code,kbd,samp,svg,math,[contenteditable]:not([contenteditable="false"]),[translate="no"],.notranslate';
  const blocks = 'p,li,h1,h2,h3,h4,h5,h6,figcaption,button,div';
  const inline = new Set(['A','SPAN','B','STRONG','I','EM','U','SMALL','S','MARK','LABEL']);
  const records = new Map(), cache = new Map(), unsafeRoots = new WeakSet();
  let enabled = true, busy = false, timer, generation = 0, failures = 0;
  let pointerTarget = null;

  function protectedText(text) {
    const value = text.replace(/^[\s•·—–\-●○□*]+|[\s•·—–\-●○□*]+$/g,'');
    return /^(?:https?:\/\/|www\.|[\w.+-]+@[\w.-]+\.[a-z]{2,})/i.test(value) ||
      /^(?:git|npm|npx|python[23]?|pip[23]?|node|swift|brew)\s+[-\w/.]/i.test(value) ||
      /^(?:GitHub|GitLab|Google|Chrome|Safari|Microsoft|OpenAI|ChatGPT|Apple|macOS|iOS|Memo)$/i.test(value) ||
      (!/\s/.test(value) && /[a-z]/i.test(value) && /[\d_/\\]|\.[a-z\d]{1,8}$/i.test(value));
  }
  function english(text) {
    const latin = (text.match(/[a-z]/gi) || []).length;
    const chinese = (text.match(/[\u3400-\u9fff]/g) || []).length;
    return !protectedText(text) && latin >= 2 && latin > chinese * 3 && text.trim().length <= 8000;
  }
  function eligible(node) {
    const parent = node.parentElement;
    if (!parent || !node.isConnected || parent.closest(skip)) return false;
    const range = document.createRange(); range.selectNodeContents(node);
    const rects = [...range.getClientRects()]; range.detach();
    if (!rects.some(r => r.width > 0 && r.height > 0 && r.bottom > -100 && r.top < innerHeight + 150 && r.right > 0 && r.left < innerWidth)) return false;
    const style = getComputedStyle(parent);
    return style.display !== 'none' && style.visibility !== 'hidden';
  }
  const sameChildren = (root, children) => root.childNodes.length === children.length && children.every((child, index) => root.childNodes[index] === child);
  const textStyle = element => {
    const s = getComputedStyle(element);
    return [s.fontFamily,s.fontSize,s.fontWeight,s.fontStyle,s.lineHeight,s.color,s.letterSpacing].join('|');
  };
  function makeUnit(node) {
    const root = node.parentElement.closest(blocks);
    if (root && !unsafeRoots.has(root)) {
      const prior = records.get(root);
      if (prior && prior.nodes.includes(node)) return null;
      const children = [...root.childNodes], nodes = [];
      let safe = children.length > 1 && children.length <= 48 && !prior;
      for (const child of children) {
        if (child.nodeType === Node.TEXT_NODE) nodes.push(child);
        else if (child.nodeType === Node.ELEMENT_NODE && inline.has(child.tagName) && child.childNodes.length === 1 && child.firstChild.nodeType === Node.TEXT_NODE && !child.closest(skip)) nodes.push(child.firstChild);
        else { safe = false; break; }
      }
      if (safe && nodes.includes(node) && nodes.every(n => !n.data.trim() || eligible(n)) && english(nodes.map(n => n.data).join(''))) {
        return { key: root, root, children, nodes, original: nodes.map(n => n.data) };
      }
    }
    return english(node.data) && eligible(node) ? { key: node, nodes: [node], original: [node.data] } : null;
  }
  function unchanged(unit) {
    return unit.nodes.every((node, index) => node.isConnected && node.data === unit.original[index]) && (!unit.root || sameChildren(unit.root, unit.children));
  }
  function owns(record) {
    return record.expected.every(([node, text]) => node.isConnected && node.data === text) && (!record.root || sameChildren(record.root, record.translatedChildren));
  }
  function restore(record, preserveEdits = false) {
    const expected = new Map(record.expected);
    record.nodes.forEach((node, index) => {
      if (node.isConnected && (!preserveEdits || node.data === expected.get(node))) node.data = record.original[index];
    });
    for (const node of record.created || []) if (node.isConnected && node.data === expected.get(node)) node.remove();
    if (record.root && sameChildren(record.root, record.translatedChildren.filter(child => !(record.created || []).includes(child)))) {
      record.root.replaceChildren(...record.children);
    }
  }
  function apply(unit, response) {
    if (!enabled || !unchanged(unit) || !unit.nodes.some(eligible) || !Array.isArray(response?.runs)) return;
    if (unit.root) {
      const selection = document.getSelection();
      // Do not move an inline link while it owns focus, is being pressed, or is
      // part of the user's selection. Apply the cached result after interaction.
      if (unit.root.contains(document.activeElement) || (pointerTarget && unit.root.contains(pointerTarget)) ||
          (selection && !selection.isCollapsed && selection.containsNode(unit.root, true))) return;
    }
    const runs = response.runs;
    if (!runs.length || runs.some(r => !Number.isInteger(r.node) || !unit.nodes[r.node] || typeof r.text !== 'string')) return;
    const record = { ...unit, expected: [], created: [] };
    if (!unit.root || !response.contextual) {
      const targets = unit.nodes.map((_, index) => runs.filter(r => r.node === index).map(r => r.text).join(''));
      unit.nodes.forEach((node, index) => {
        const leading = unit.original[index].match(/^\s*/)[0], trailing = unit.original[index].match(/\s*$/)[0];
        node.data = targets[index].trim() ? leading + targets[index].trim() + trailing : unit.original[index];
        record.expected.push([node, node.data]);
      });
      record.translatedChildren = unit.children;
    } else {
      const styled = unit.nodes.map(node => node.parentElement === unit.root ? null : node.parentElement);
      if (styled.some((element, index) => element && runs.filter(r => r.node === index).length !== 1)) return;
      const before = styled.map(element => element && textStyle(element));
      const used = new Set(), children = [];
      for (const run of runs) {
        let node = unit.nodes[run.node];
        if (used.has(run.node)) { node = document.createTextNode(''); record.created.push(node); }
        used.add(run.node); node.data = run.text; record.expected.push([node, run.text]);
        children.push(styled[run.node] || node);
      }
      unit.nodes.forEach((node, index) => { if (!used.has(index)) { node.data = ''; record.expected.push([node, '']); children.push(styled[index] || node); } });
      unit.root.replaceChildren(...children);
      record.translatedChildren = [...unit.root.childNodes];
      if (styled.some((element, index) => element && textStyle(element) !== before[index])) {
        restore(record); unsafeRoots.add(unit.root); schedule(); return;
      }
    }
    records.set(unit.key, record);
  }
  function schedule(delay = 180) {
    clearTimeout(timer);
    if (enabled && !document.hidden) timer = setTimeout(scan, delay);
  }
  async function scan() {
    if (!enabled || busy || document.hidden) return;
    const version = generation;
    for (const [key, record] of records) {
      if (!key.isConnected) { records.delete(key); continue; }
      if (!owns(record)) { restore(record, true); records.delete(key); if (record.root) unsafeRoots.add(record.root); }
    }
    const owned = new Set([...records.values()].flatMap(record => record.nodes.concat(record.created || [])));
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    const batch = [], consumed = new Set();
    let walked = 0;
    for (let node = walker.nextNode(); node && walked++ < 16000 && batch.length < 24; node = walker.nextNode()) {
      if (owned.has(node) || !node.data.trim() || !eligible(node)) continue;
      const unit = makeUnit(node);
      if (!unit || consumed.has(unit.key)) continue;
      consumed.add(unit.key);
      unit.segments = unit.nodes.map((n, index) => ({ text: unit.original[index], plain: !unit.root || n.parentElement === unit.root, protected: protectedText(unit.original[index]) }));
      unit.cacheKey = JSON.stringify(unit.segments);
      if (cache.has(unit.cacheKey)) { apply(unit, cache.get(unit.cacheKey)); continue; }
      batch.push(unit);
    }
    if (!batch.length) return;
    busy = true;
    try {
      const response = await chrome.runtime.sendMessage({ type: 'translateUnits', units: batch.map(unit => unit.segments) });
      if (response?.error || response?.units?.length !== batch.length) throw new Error(response?.error || 'Incomplete response');
      if (version !== generation || !enabled) return;
      response.units.forEach((result, index) => { cache.set(batch[index].cacheKey, result); apply(batch[index], result); });
      failures = 0;
      if (cache.size > 2000) { const recent = [...cache].slice(-1000); cache.clear(); recent.forEach(([a,b]) => cache.set(a,b)); }
    } catch { failures++; }
    finally { busy = false; schedule(failures ? Math.min(30000, 2000 * failures) : 80); }
  }
  function setEnabled(value) {
    enabled = value; generation++; clearTimeout(timer);
    notifyVisibility();
    if (!enabled) { for (const record of records.values()) restore(record, true); records.clear(); }
    else schedule();
  }
  const observer = new MutationObserver(() => schedule());
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] });
  addEventListener('scroll', () => schedule(), { passive: true });
  addEventListener('resize', () => schedule());
  document.addEventListener('pointerdown', event => { pointerTarget = event.target; }, true);
  document.addEventListener('pointerup', () => { pointerTarget = null; schedule(); }, true);
  document.addEventListener('pointercancel', () => { pointerTarget = null; schedule(); }, true);
  document.addEventListener('focusout', () => schedule(), true);
  document.addEventListener('selectionchange', () => { if (document.getSelection()?.isCollapsed) schedule(); });
  function notifyVisibility() {
    if (self !== top) return;
    chrome.runtime.sendMessage({ type:'pageVisibility', active:enabled && !document.hidden, browser:/Edg\//.test(navigator.userAgent) ? 'edge' : 'chrome' }).catch(() => {});
  }
  document.addEventListener('visibilitychange', () => { notifyVisibility(); if (!document.hidden) schedule(); });
  setInterval(() => { if (enabled && !document.hidden) notifyVisibility(); }, 2000);
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.enabled) setEnabled(changes.enabled.newValue !== false); });
  chrome.storage.local.get({ enabled: true }).then(settings => setEnabled(settings.enabled));
})();
