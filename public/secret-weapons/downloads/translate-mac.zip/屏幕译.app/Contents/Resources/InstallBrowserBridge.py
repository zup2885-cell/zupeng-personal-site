#!/usr/bin/env python3
"""Register only this extension's offline native host, after the user requests setup."""
from pathlib import Path
import argparse, json, plistlib

def configure(app: Path, browsers):
    app = app.expanduser().resolve()
    info = plistlib.loads((app / 'Contents/Info.plist').read_bytes())
    if info.get('CFBundleIdentifier') != 'local.azu.screentranslate':
        raise ValueError('Select the installed Screen Translate app')
    binary = app / 'Contents/MacOS' / info['CFBundleExecutable']
    extension_id = (app / 'Contents/Resources/BrowserExtension/extension-id.txt').read_text().strip()
    manifest = {'name': 'local.azu.screentranslate.browser', 'description': 'Offline English to Chinese webpage translation',
                'path': str(binary), 'type': 'stdio', 'allowed_origins': ['chrome-extension://' + extension_id + '/']}
    directories = {'chrome': 'Google/Chrome', 'edge': 'Microsoft Edge'}
    for browser in browsers:
        folder = Path.home() / 'Library/Application Support' / directories[browser] / 'NativeMessagingHosts'
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / (manifest['name'] + '.json')
        if target.exists():
            old = json.loads(target.read_text())
            if old.get('allowed_origins') != manifest['allowed_origins']:
                raise ValueError('Existing native host has a different extension identity')
        target.write_text(json.dumps(manifest, indent=2))
        print(target)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--app', type=Path, required=True)
    parser.add_argument('--browser', action='append', choices=['chrome', 'edge'], required=True)
    args = parser.parse_args()
    configure(args.app, args.browser)
